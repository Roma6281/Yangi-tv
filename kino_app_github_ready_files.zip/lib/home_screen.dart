import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text("YANGI.TV uslubi", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Katta baner
            Container(
              height: 200,
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                  image: NetworkImage("https://via.placeholder.com/400x200"),
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // Janrlar bo‘limi
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Janrlar", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            SizedBox(
              height: 120,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  genreItem("Arguzasht", "https://via.placeholder.com/100x150"),
                  genreItem("Fantastika", "https://via.placeholder.com/100x150"),
                  genreItem("Tarixiy", "https://via.placeholder.com/100x150"),
                ],
              ),
            ),

            // Tarjima filmlar
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Tarjima filmlar", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            SizedBox(
              height: 220,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  movieItem("Mangu oq ayiq", "https://via.placeholder.com/150x220"),
                  movieItem("Bembi", "https://via.placeholder.com/150x220"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget genreItem(String name, String imageUrl) {
    return Container(
      width: 100,
      margin: const EdgeInsets.only(left: 8),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(imageUrl, height: 80, width: 100, fit: BoxFit.cover),
          ),
          SizedBox(height: 5),
          Text(name, style: TextStyle(fontSize: 14))
        ],
      ),
    );
  }

  Widget movieItem(String title, String imageUrl) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(left: 8),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(imageUrl, height: 180, width: 150, fit: BoxFit.cover),
          ),
          SizedBox(height: 5),
          Text(title, style: TextStyle(fontSize: 14))
        ],
      ),
    );
  }
}
